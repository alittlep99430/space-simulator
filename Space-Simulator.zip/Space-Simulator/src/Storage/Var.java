package Storage;

import java.util.Scanner;
import java.util.Random;

public class Var {
  public static String novaClubString = "";
  public static String mainGunsName = "Pew Pew";
  public static String chargedGunName = "Pulsator";
  public static String shipBodyName = "Baby Ship";

  public static boolean morianMines = true;
  public static boolean cecilMines = true;
  public static boolean dudinMines = true;
  public static boolean falornlMines = true;
  public static boolean novaClub = false;
  public static boolean isDone = false;
  public static double health = (int) 5.0;
  public static double maxHealth = 5.0;
  public static int cd = 0;
  public static int mainGuns = 1;
  public static int poweredGuns = 3;
  public static double banditHealth = 4;
  public static double banditMainGuns = 1;
  public static double banditPoweredGun = 2;
  public static double territory = 0.0;
  public static boolean fightDone = false;
  public static String name = "Ceaser";
  public static String name1 = "";
  public static Scanner sc = new Scanner(System.in);
  public static Random rand = new Random();
  String str = sc.nextLine();
}